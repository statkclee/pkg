test_that("tiger roars", {
  expect_message(roar(), "roar")
})
