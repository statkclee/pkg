library(testthat)
library(tiger)

test_check("tiger")
